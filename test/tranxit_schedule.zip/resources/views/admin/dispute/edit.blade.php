@extends('admin.layout.base')

@section('title', 'Update Dispute ')

@section('content')

<div class="content-area py-1">
    <div class="container-fluid">
    	<div class="box box-block bg-white">
    	    
		</div>
    </div>
</div>

@endsection
