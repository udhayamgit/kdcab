$(document).ready(function(){

	/* =================================================================
		Summernote
	================================================================= */

	$('#summernote').summernote();

	$('#summernote-air').summernote({
		airMode: true
	});

});