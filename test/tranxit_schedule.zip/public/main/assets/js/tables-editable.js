$(document).ready(function() {

   $('#table-1').editableTableWidget();

});