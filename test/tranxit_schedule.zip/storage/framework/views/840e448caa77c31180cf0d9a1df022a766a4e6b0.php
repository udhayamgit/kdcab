<?php $__env->startSection('title', 'Upcoming Trips '); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-9">
    <div class="dash-content">
        <div class="row no-margin">
            <div class="col-md-12">
                <h4 class="page-title"><?php echo app('translator')->get('user.upcoming_trips'); ?></h4>
            </div>
        </div>

        <div class="row no-margin ride-detail">
            <div class="col-md-12">
            <?php if($trips->count() > 0): ?>

                <table class="table table-condensed" style="border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th>&nbsp;</th>
                            <th><?php echo app('translator')->get('user.booking_id'); ?></th>
                            <th><?php echo app('translator')->get('user.schedule_date'); ?></th>
                            <th><?php echo app('translator')->get('user.type'); ?></th>
                            <th><?php echo app('translator')->get('user.payment'); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                        <tr data-toggle="collapse" data-target="#trip_<?php echo e($trip->id); ?>" class="accordion-toggle collapsed">
                            <td><span class="arrow-icon fa fa-chevron-right"></span></td>
                            <td><?php echo e($trip->booking_id); ?></td>
                            <td><?php echo e(date('d-m-Y H:i:s',strtotime($trip->schedule_at))); ?></td>
                            <td><?php echo e($trip->service_type->name); ?></td>
                            <td><?php echo app('translator')->get('user.paid_via'); ?> <?php echo e($trip->payment_mode); ?></td>
                        </tr>
                        <tr class="hiddenRow">
                            <td colspan="6">
                                <div class="accordian-body collapse row" id="trip_<?php echo e($trip->id); ?>">
                                    <div class="col-md-6">
                                        <div class="my-trip-left">
                                        <?php 
                                    $map_icon = asset('asset/img/marker-start.png');
                                    $static_map = "https://maps.googleapis.com/maps/api/staticmap?autoscale=1&size=600x450&maptype=terrain&format=png&visual_refresh=true&markers=icon:".$map_icon."%7C".$trip->s_latitude.",".$trip->s_longitude."&markers=icon:".$map_icon."%7C".$trip->d_latitude.",".$trip->d_longitude."&path=color:0x191919|weight:8|enc:".$trip->route_key."&key=".env('GOOGLE_MAP_KEY'); ?>
                                            <div class="map-static" style="background-image: url(<?php echo e($static_map); ?>);">
                                                
                                            </div>
                                            <div class="from-to row no-margin">
                                                <div class="from">
                                                    <h5><?php echo app('translator')->get('user.from'); ?></h5>
                                                    <p><?php echo e($trip->s_address); ?></p>
                                                </div>
                                                <div class="to">
                                                    <h5><?php echo app('translator')->get('user.to'); ?></h5>
                                                    <p><?php echo e($trip->d_address); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">

                                        <div class="mytrip-right">
                                             <h5>Provider Details</h5>
                                             <div class="trip-user">
                                                <div class="user-img" style="background-image: url(<?php echo e(img($trip->provider->avatar)); ?>);">
                                                </div>
                                                <div class="user-right">
                                                    <h5><?php echo e($trip->provider->first_name); ?> <?php echo e($trip->provider->last_name); ?></h5>
                                                    <p><?php echo e($trip->status); ?></p>
                                                </div>
                                            </div>

                                            <div class="fare-break">

                                               <form method="POST" action="<?php echo e(url('cancel/ride')); ?>">
                                                  <?php echo e(csrf_field()); ?>

                                                     <input type="hidden" name="request_id" value="<?php echo e($trip->id); ?>" />
                                                   <button class="full-primary-btn fare-btn" type="submit">Cancel Ride</button>
                                               </form>

                                            </div>


                                        </div>

                                    </div>

                                </div>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                    </tbody>
                </table>
                <?php else: ?>
                    <hr>
                    <p style="text-align: center;">No trips Available</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>