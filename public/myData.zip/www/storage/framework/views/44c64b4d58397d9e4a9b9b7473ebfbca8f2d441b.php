<?php $__env->startSection('title', 'My Trips '); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-9">
    <div class="dash-content">
        <div class="row no-margin">
            <div class="col-md-12">
                <h4 class="page-title"><?php echo app('translator')->get('user.my_trips'); ?></h4>
            </div>
        </div>

        <div class="row no-margin ride-detail">
            <div class="col-md-12">
                <table class="table table-condensed" style="border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th>1</th>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Amount</th>
                            <th>Type</th>
                            <th>Payment</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr data-toggle="collapse" data-target="data" class="accordion-toggle collapsed">
                            <td><span class="arrow-icon fa fa-chevron-right"></span></td>
                            <td></td>
                            <td></td>
                                <td></td>
                                <td></td>
                                <td>-</td>
                                <td></td>
                                <td>-</td>
                            <td></td>
                        </tr>
                        <tr class="hiddenRow">
                            <td colspan="12">
                                <div class="accordian-body collapse row" id="data">
                                    <div class="col-md-6">
                                        <div class="my-trip-left">
                                        
                                            <div class="map-static">
                                                <img src="" height="280px;">
                                            </div>
                                            <div class="from-to row no-margin">
                                                <div class="from">
                                                    <h5></h5>
                                                    <h6></h6>
                                                    <p></p>
                                                </div>
                                                <div class="to">
                                                    <h5></h5>
                                                    <h6></h6>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">

                                        <div class="mytrip-right">

                                            <div class="fare-break">

                                                <h4 class="text-center">
                                                <strong></strong></h4>

                                                <h5><span>
                                                
                                                </span></h5>
                                                <h5><span>
                                                
                                                </span></h5>
                                                
                                                        <h5><span>
                                                            
                                                        </span></h5>
                                                
                                                    
                                                        <h5><span>
                                                            
                                                        </span></h5>
                                                <h5><strong></strong><span><strong>
                                                
                                                </strong></span></h5>
                                                <h5 class="big"><strong> </strong><span><strong>
                                                
                                                </strong></span></h5>

                                            </div>

                                            <div class="trip-user">
                                                <div class="user-img">
                                                </div>
                                                <div class="user-right">
                                                    
                                                        <h5></h5>
                                                   
                                                    <h5>- </h5>
                                                    <div class="rating-outer">
                                                        <input type="hidden" class="rating" value="" />

                                                    </div>
                                                    <p></p>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                    <hr>
                    <p style="text-align: center;">No trips Available</p>
            </div>
        </div>

        <div class="row no-margin ride-detail">
            <div class="col-md-12">
            <?php if($trips->count() > 0): ?>

                <table class="table table-condensed" style="border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th>&nbsp;</th>
                            <th><?php echo app('translator')->get('user.booking_id'); ?></th>
                            <th><?php echo app('translator')->get('user.date'); ?></th>
                            <th><?php echo app('translator')->get('user.profile.name'); ?></th>
                            <th><?php echo app('translator')->get('user.amount'); ?></th>
                            <th><?php echo app('translator')->get('user.type'); ?></th>
                            <th><?php echo app('translator')->get('user.payment'); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                        <tr data-toggle="collapse" data-target="#trip_<?php echo e($trip->id); ?>" class="accordion-toggle collapsed">
                            <td><span class="arrow-icon fa fa-chevron-right"></span></td>
                            <td><?php echo e($trip->booking_id); ?></td>
                            <td><?php echo e(date('d-m-Y',strtotime($trip->assigned_at))); ?></td>
                            <?php if($trip->provider): ?>
                                <td><?php echo e($trip->provider->first_name); ?> <?php echo e($trip->provider->last_name); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>
                            <?php if($trip->payment): ?>
                                <td><?php echo e(currency($trip->payment->total)); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>
                            <?php if($trip->service_type): ?>
                                <td><?php echo e($trip->service_type->name); ?></td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>
                            <td><?php echo app('translator')->get('user.paid_via'); ?> <?php echo e($trip->payment_mode); ?></td>
                        </tr>
                        <tr class="hiddenRow">
                            <td colspan="12">
                                <div class="accordian-body collapse row" id="trip_<?php echo e($trip->id); ?>">
                                    <div class="col-md-6">
                                        <div class="my-trip-left">
                                        <?php 
                                    $map_icon = asset('asset/img/marker-start.png');
                                    $static_map = "https://maps.googleapis.com/maps/api/staticmap?autoscale=1&size=600x450&maptype=terrain&format=png&visual_refresh=true&markers=icon:".$map_icon."%7C".$trip->s_latitude.",".$trip->s_longitude."&markers=icon:".$map_icon."%7C".$trip->d_latitude.",".$trip->d_longitude."&path=color:0x191919|weight:8|enc:".$trip->route_key."&key=".Setting::get('map_key'); ?>
                                            <div class="map-static">
                                                <img src="<?php echo e($static_map); ?>" height="280px;">
                                            </div>
                                            <div class="from-to row no-margin">
                                                <div class="from">
                                                    <h5><?php echo app('translator')->get('user.from'); ?></h5>
                                                    <h6><?php echo e(date('H:i A - d-m-y', strtotime($trip->started_at))); ?></h6>
                                                    <p><?php echo e($trip->s_address); ?></p>
                                                </div>
                                                <div class="to">
                                                    <h5><?php echo app('translator')->get('user.to'); ?></h5>
                                                    <h6><?php echo e(date('H:i A - d-m-y', strtotime($trip->finished_at))); ?></h6>
                                                    <p><?php echo e($trip->d_address); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">

                                        <div class="mytrip-right">

                                            <div class="fare-break">

                                                <h4 class="text-center">
                                                <strong>
                                                <?php if($trip->service_type): ?>
                                                    <?php echo e($trip->service_type->name); ?>

                                                <?php endif; ?>
                                                 - <?php echo app('translator')->get('user.fare_breakdown'); ?></strong></h4>

                                                <h5><?php echo app('translator')->get('user.ride.base_price'); ?> <span>
                                                <?php if($trip->payment): ?>
                                                    <?php echo e(currency($trip->payment->fixed)); ?>

                                                <?php endif; ?>

                                                </span></h5>
                                                <h5><?php echo app('translator')->get('user.ride.distance_price'); ?> <span>
                                                <?php if($trip->payment): ?>
                                                    <?php echo e(currency($trip->payment->distance)); ?>

                                                <?php endif; ?>
                                                
                                                </span></h5>
                                                 <?php if($trip->payment): ?>
                                                    <?php if($trip->payment->wallet): ?>
                                                        <h5><?php echo app('translator')->get('user.ride.wallet_deduction'); ?> <span>
                                                            <?php echo e(currency($trip->payment->wallet)); ?>

                                                        </span></h5>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($trip->payment): ?>
                                                    <?php if($trip->payment->discount): ?>
                                                        <h5><?php echo app('translator')->get('user.ride.promotion_applied'); ?> <span>
                                                            <?php echo e(currency($trip->payment->discount)); ?>

                                                        </span></h5>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <h5><strong><?php echo app('translator')->get('user.ride.tax_price'); ?> </strong><span><strong>
                                                <?php if($trip->payment): ?>
                                                <?php echo e(currency($trip->payment->tax)); ?>

                                                <?php endif; ?>
                                                </strong></span></h5>
                                                <h5 class="big"><strong><?php echo app('translator')->get('user.charged'); ?> - <?php echo e($trip->payment_mode); ?> </strong><span><strong>
                                                <?php if($trip->payment): ?>
                                                <?php echo e(currency($trip->payment->total)); ?>

                                                <?php endif; ?>
                                                </strong></span></h5>

                                            </div>

                                            <div class="trip-user">
                                                <div class="user-img" style="background-image: url(<?php echo e(img($trip->provider->avatar)); ?>);">
                                                </div>
                                                <div class="user-right">
                                                    <?php if($trip->provider): ?>
                                                        <h5><?php echo e($trip->provider->first_name); ?> <?php echo e($trip->provider->last_name); ?></h5>
                                                    <?php else: ?>
                                                    <h5>- </h5>
                                                    <?php endif; ?>
                                                    <?php if($trip->rating): ?>
                                                    <div class="rating-outer">
                                                        <input type="hidden" class="rating" value="<?php echo e($trip->rating->user_rated); ?>" />

                                                    </div>
                                                    <p><?php echo e($trip->rating->user_comment); ?></p>
                                                     <?php else: ?>
                                                        -
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                    </tbody>
                </table>
                <?php else: ?>
                    <hr>
                    <p style="text-align: center;">No trips Available</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>