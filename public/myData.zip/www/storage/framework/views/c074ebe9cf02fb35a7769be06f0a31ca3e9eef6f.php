<?php $__env->startSection('title', 'Provider Documents '); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
            <h5 class="mb-1"><?php echo app('translator')->get('admin.provides.type_allocation'); ?></h5>
            <div class="row">
                <div class="col-xs-12">
                    <?php if($ProviderService->count() > 0): ?>
                    <hr><h6>Allocated Services :  </h6>
                    <table class="table table-striped table-bordered dataTable">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('admin.provides.service_name'); ?></th>
                                <th><?php echo app('translator')->get('admin.provides.service_number'); ?></th>
                                <th><?php echo app('translator')->get('admin.provides.service_model'); ?></th>
                                <th><?php echo app('translator')->get('admin.action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ProviderService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($service->service_type->name); ?></td>
                                <td><?php echo e($service->service_number); ?></td>
                                <td><?php echo e($service->service_model); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.provider.document.service', [$Provider->id, $service->id])); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button class="btn btn-danger btn-large btn-block">Delete</a>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th><?php echo app('translator')->get('admin.provides.service_name'); ?></th>
                                <th><?php echo app('translator')->get('admin.provides.service_number'); ?></th>
                                <th><?php echo app('translator')->get('admin.provides.service_model'); ?></th>
                                <th><?php echo app('translator')->get('admin.action'); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                    <?php endif; ?>
                    <hr>
                </div>
                <form action="<?php echo e(route('admin.provider.document.store', $Provider->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-xs-3">
                        <select class="form-control input" name="service_type" required>
                            <?php $__empty_1 = true; $__currentLoopData = $ServiceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($Type->id); ?>"><?php echo e($Type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                            <option>- Please Create a Service Type -</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-xs-3">
                        <input type="text" required name="service_number" class="form-control" placeholder="Number (CY 98769)">
                    </div>
                    <div class="col-xs-3">
                        <input type="text" required name="service_model" class="form-control" placeholder="Model (Audi R8 - Black)">
                    </div>
                    <div class="col-xs-3">
                        <button class="btn btn-primary btn-block" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="box box-block bg-white">
            <h5 class="mb-1"><?php echo app('translator')->get('admin.provides.provider_documents'); ?></h5>
            <table class="table table-striped table-bordered dataTable" id="table-2">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('admin.provides.document_type'); ?></th>
                        <th><?php echo app('translator')->get('admin.status'); ?></th>
                        <th><?php echo app('translator')->get('admin.action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Provider->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Index => $Document): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($Index + 1); ?></td>
                        <td><?php echo e($Document->document->name); ?></td>
                        <td><?php echo e($Document->status); ?></td>
                        <td>
                            <div class="input-group-btn">
                                <a href="<?php echo e(route('admin.provider.document.edit', [$Provider->id, $Document->id])); ?>"><span class="btn btn-success btn-large">View</span></a>
                                <button class="btn btn-danger btn-large" form="form-delete">Delete</button>
                                <form action="<?php echo e(route('admin.provider.document.destroy', [$Provider->id, $Document->id])); ?>" method="POST" id="form-delete">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('admin.provides.document_type'); ?></th>
                        <th><?php echo app('translator')->get('admin.status'); ?></th>
                        <th><?php echo app('translator')->get('admin.action'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>