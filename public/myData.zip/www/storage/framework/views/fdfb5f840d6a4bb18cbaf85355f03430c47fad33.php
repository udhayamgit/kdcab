<!-- Main Content -->
<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <a class="log-blk-btn" href="<?php echo e(url('/provider/login')); ?>">ALREADY HAVE AN ACCOUNT?</a>
        <h3>Reset Password</h3>
    </div>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <form role="form" method="POST" action="<?php echo e(url('/provider/password/email')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="col-md-12">
            <input type="email" class="form-control" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>">

            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>                        
        </div>

        <div class="col-md-12">
            <button class="log-teal-btn" type="submit">SEND PASSWORD RESET LINK</button>
        </div>
    </form>     


<?php $__env->stopSection(); ?>



<?php echo $__env->make('provider.layout.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>