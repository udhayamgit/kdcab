<?php $__env->startSection('title', 'Payment History '); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-area py-1">
        <div class="container-fluid">
            <div class="box box-block bg-white">
                <h5 class="mb-1"><?php echo app('translator')->get('admin.payment.payment_history'); ?></h5>
                <table class="table table-striped table-bordered dataTable" id="table-2">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('admin.payment.request_id'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.transaction_id'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.from'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.to'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.total_amount'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.provider_amount'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.payment_mode'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.payment_status'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td><?php echo e($payment->id); ?></td>
                            <td><?php echo e($payment->payment->payment_id); ?></td>
                            <td><?php echo e($payment->user?$payment->user->first_name:''); ?> <?php echo e($payment->user?$payment->user->last_name:''); ?></td>
                            <td><?php echo e($payment->provider?$payment->provider->first_name:''); ?> <?php echo e($payment->provider?$payment->provider->last_name:''); ?></td>
                            <td><?php echo e(currency($payment->payment->total)); ?></td>
                            <td><?php echo e(currency($payment->payment->provider_pay)); ?></td>
                            <td><?php echo e($payment->payment_mode); ?></td>
                            <td>
                                <?php if($payment->paid): ?>
                                    Paid
                                <?php else: ?>
                                    Not Paid
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th><?php echo app('translator')->get('admin.payment.request_id'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.transaction_id'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.from'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.to'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.total_amount'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.provider_amount'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.payment_mode'); ?></th>
                            <th><?php echo app('translator')->get('admin.payment.payment_status'); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>