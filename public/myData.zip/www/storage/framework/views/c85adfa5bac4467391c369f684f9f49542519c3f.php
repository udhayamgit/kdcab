<?php $__env->startSection('title', 'Users '); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
           <?php if(Setting::get('demo_mode') == 1): ?>
        <div class="col-md-12" style="height:50px;color:red;">
                    ** Demo Mode : No Permission to Edit and Delete.
                </div>
                <?php endif; ?>
            <h5 class="mb-1">
                <?php echo app('translator')->get('admin.users.Users'); ?>
                <?php if(Setting::get('demo_mode', 0) == 1): ?>
                <span class="pull-right">(*personal information hidden in demo)</span>
                <?php endif; ?>
            </h5>
            <a href="<?php echo e(route('admin.user.create')); ?>" style="margin-left: 1em;" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Add New User</a>
            <table class="table table-striped table-bordered dataTable" id="table-2">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('admin.id'); ?></th>
                        <th><?php echo app('translator')->get('admin.first_name'); ?></th>
                        <th><?php echo app('translator')->get('admin.last_name'); ?></th>
                        <th><?php echo app('translator')->get('admin.email'); ?></th>
                        <th><?php echo app('translator')->get('admin.mobile'); ?></th>
                        <th><?php echo app('translator')->get('admin.users.Rating'); ?></th>
                        <th><?php echo app('translator')->get('admin.users.Wallet_Amount'); ?></th>
                        <th><?php echo app('translator')->get('admin.action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($user->first_name); ?></td>
                        <td><?php echo e($user->last_name); ?></td>
                        <?php if(Setting::get('demo_mode', 0) == 1): ?>
                        <td><?php echo e(substr($user->email, 0, 3).'****'.substr($user->email, strpos($user->email, "@"))); ?></td>
                        <?php else: ?>
                        <td><?php echo e($user->email); ?></td>
                        <?php endif; ?>
                        <?php if(Setting::get('demo_mode', 0) == 1): ?>
                        <td>+919876543210</td>
                        <?php else: ?>
                        <td><?php echo e($user->mobile); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($user->rating); ?></td>
                        <td><?php echo e(currency().$user->wallet_balance); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.user.destroy', $user->id)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE">
                                <a href="<?php echo e(route('admin.user.request', $user->id)); ?>" class="btn btn-info"><i class="fa fa-search"></i> <?php echo app('translator')->get('admin.History'); ?></a>
                                <?php if( Setting::get('demo_mode') == 0): ?>
                                <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" class="btn btn-info"><i class="fa fa-pencil"></i> <?php echo app('translator')->get('admin.edit'); ?></a>
                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i> <?php echo app('translator')->get('admin.delete'); ?></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo app('translator')->get('admin.id'); ?></th>
                        <th><?php echo app('translator')->get('admin.first_name'); ?></th>
                        <th><?php echo app('translator')->get('admin.last_name'); ?></th>
                        <th><?php echo app('translator')->get('admin.email'); ?></th>
                        <th><?php echo app('translator')->get('admin.mobile'); ?></th>
                        <th><?php echo app('translator')->get('admin.users.Rating'); ?></th>
                        <th><?php echo app('translator')->get('admin.users.Wallet_Amount'); ?></th>
                        <th><?php echo app('translator')->get('admin.action'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>