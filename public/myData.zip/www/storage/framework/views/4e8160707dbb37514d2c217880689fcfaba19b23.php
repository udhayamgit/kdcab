<div class="site-sidebar">
	<div class="custom-scroll custom-scroll-light">
		<ul class="sidebar-menu">
			<li class="menu-title"><?php echo app('translator')->get('admin.include.admin_dashboard'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-anchor"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.dashboard'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.dispatcher.index')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-target"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.dispatcher_panel'); ?></span>
				</a>
			</li>
			
			<li>
				<a href="<?php echo e(route('admin.heatmap')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-map"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.heat_map'); ?></span>
				</a>
			</li>
			
			<li class="menu-title"><?php echo app('translator')->get('admin.include.members'); ?></li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-crown"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.users'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.user.index')); ?>"><?php echo app('translator')->get('admin.include.list_users'); ?></a></li>
					<li><a href="<?php echo e(route('admin.user.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_user'); ?></a></li>
				</ul>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-car"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.providers'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.provider.index')); ?>"><?php echo app('translator')->get('admin.include.list_providers'); ?></a></li>
					<li><a href="<?php echo e(route('admin.provider.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_provider'); ?></a></li>
				</ul>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-crown"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.dispatcher'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.dispatch-manager.index')); ?>"><?php echo app('translator')->get('admin.include.list_dispatcher'); ?></a></li>
					<li><a href="<?php echo e(route('admin.dispatch-manager.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_dispatcher'); ?></a></li>
				</ul>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-crown"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.fleet_owner'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.fleet.index')); ?>"><?php echo app('translator')->get('admin.include.list_fleets'); ?></a></li>
					<li><a href="<?php echo e(route('admin.fleet.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_fleet_owner'); ?></a></li>
				</ul>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-crown"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.account_manager'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.account-manager.index')); ?>"><?php echo app('translator')->get('admin.include.list_account_managers'); ?></a></li>
					<li><a href="<?php echo e(route('admin.account-manager.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_account_manager'); ?></a></li>
				</ul>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.accounts'); ?></li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-crown"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.statements'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.ride.statement')); ?>"><?php echo app('translator')->get('admin.include.overall_ride_statments'); ?></a></li>
					<li><a href="<?php echo e(route('admin.ride.statement.provider')); ?>"><?php echo app('translator')->get('admin.include.provider_statement'); ?></a></li>
					<li><a href="<?php echo e(route('admin.ride.statement.today')); ?>"><?php echo app('translator')->get('admin.include.daily_statement'); ?></a></li>
					<li><a href="<?php echo e(route('admin.ride.statement.monthly')); ?>"><?php echo app('translator')->get('admin.include.monthly_statement'); ?></a></li>
					<li><a href="<?php echo e(route('admin.ride.statement.yearly')); ?>"><?php echo app('translator')->get('admin.include.yearly_statement'); ?></a></li>
				</ul>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.details'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.map.index')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-map-alt"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.map'); ?></span>
				</a>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-view-grid"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.ratings'); ?> &amp; <?php echo app('translator')->get('admin.include.reviews'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.user.review')); ?>"><?php echo app('translator')->get('admin.include.user_ratings'); ?></a></li>
					<li><a href="<?php echo e(route('admin.provider.review')); ?>"><?php echo app('translator')->get('admin.include.provider_ratings'); ?></a></li>
				</ul>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.requests'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.requests.index')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-infinite"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.request_history'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.requests.scheduled')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-palette"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.scheduled_rides'); ?></span>
				</a>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.general'); ?></li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-view-grid"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.service_types'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.service.index')); ?>"><?php echo app('translator')->get('admin.include.list_service_types'); ?></a></li>
					<li><a href="<?php echo e(route('admin.service.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_service_type'); ?></a></li>
				</ul>
			</li>
			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-layout-tab"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.documents'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.document.index')); ?>"><?php echo app('translator')->get('admin.include.list_documents'); ?></a></li>
					<li><a href="<?php echo e(route('admin.document.create')); ?>"><?php echo app('translator')->get('admin.include.add_new_document'); ?></a></li>
				</ul>
			</li>

			<li class="with-sub">
				<a href="#" class="waves-effect  waves-light">
					<span class="s-caret"><i class="fa fa-angle-down"></i></span>
					<span class="s-icon"><i class="ti-layout-tab"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.promocodes'); ?></span>
				</a>
				<ul>
					<li><a href="<?php echo e(route('admin.promocode.index')); ?>"><?php echo app('translator')->get('admin.include.list_promocodes'); ?></a></li>
					<li><a href="<?php echo e(route('admin.promocode.create')); ?>">
					<?php echo app('translator')->get('admin.include.add_new_promocode'); ?></a></li>
				</ul>
			</li>
			
			<li class="menu-title"><?php echo app('translator')->get('admin.include.payment_details'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.payment')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-infinite"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.payment_history'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.settings.payment')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-money"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.payment_settings'); ?></span>
				</a>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.settings'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.settings')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-settings"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.site_settings'); ?></span>
				</a>
			</li>
			
			<li class="menu-title"><?php echo app('translator')->get('admin.include.others'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.privacy')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-help"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.privacy_policy'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.help')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-help"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.help'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.push')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-smallcap"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.custom_push'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.translation')); ?>" class="waves-effect waves-light">
					<span class="s-icon"><i class="ti-smallcap"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.translations'); ?></span>
				</a>
			</li>
			<li class="menu-title"><?php echo app('translator')->get('admin.include.account'); ?></li>
			<li>
				<a href="<?php echo e(route('admin.profile')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-user"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.account_settings'); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.password')); ?>" class="waves-effect  waves-light">
					<span class="s-icon"><i class="ti-exchange-vertical"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.change_password'); ?></span>
				</a>
			</li>
			<li class="compact-hide">
				<a href="<?php echo e(url('/admin/logout')); ?>"
                            onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
					<span class="s-icon"><i class="ti-power-off"></i></span>
					<span class="s-text"><?php echo app('translator')->get('admin.include.logout'); ?></span>
                </a>

                <form id="logout-form" action="<?php echo e(url('/admin/logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
			</li>
			
		</ul>
	</div>
</div>