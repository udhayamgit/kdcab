<?php $__env->startSection('title', 'Add Service Type '); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area py-1">
    <div class="container-fluid">
        <div class="box box-block bg-white">
            <a href="<?php echo e(route('admin.service.index')); ?>" class="btn btn-default pull-right"><i class="fa fa-angle-left"></i> <?php echo app('translator')->get('admin.back'); ?></a>

            <h5 style="margin-bottom: 2em;"><?php echo app('translator')->get('admin.service.Add_Service_Type'); ?></h5>

            <form class="form-horizontal" action="<?php echo e(route('admin.service.store')); ?>" method="POST" enctype="multipart/form-data" role="form">
                <?php echo e(csrf_field()); ?>

                <div class="form-group row">
                    <label for="name" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Service_Name'); ?></label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('name')); ?>" name="name" required id="name" placeholder="Service Name">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="provider_name" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Provider_Name'); ?></label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('provider_name')); ?>" name="provider_name" required id="provider_name" placeholder="Provider Name">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="picture" class="col-xs-12 col-form-label">
                    <?php echo app('translator')->get('admin.service.Service_Image'); ?></label>
                    <div class="col-xs-10">
                        <input type="file" accept="image/*" name="image" class="dropify form-control-file" id="picture" aria-describedby="fileHelp">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="fixed" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Base_Price'); ?> (<?php echo e(currency()); ?>)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('fixed')); ?>" name="fixed" required id="fixed" placeholder="Base Price">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="distance" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Base_Distance'); ?> (<?php echo e(distance()); ?>)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('distance')); ?>" name="distance" required id="distance" placeholder="Base Distance">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="minute" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.unit_time'); ?></label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('minute')); ?>" name="minute" required id="minute" placeholder="Unit Time Pricing">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="price" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.unit'); ?>(<?php echo e(distance()); ?>)</label>
                    <div class="col-xs-10">
                        <input class="form-control" type="text" value="<?php echo e(old('price')); ?>" name="price" required id="price" placeholder="Unit Distance Price">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="capacity" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Seat_Capacity'); ?></label>
                    <div class="col-xs-10">
                        <input class="form-control" type="number" value="<?php echo e(old('capacity')); ?>" name="capacity" required id="capacity" placeholder="Capacity">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="calculator" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Pricing_Logic'); ?></label>
                    <div class="col-xs-10">
                        <select class="form-control" id="calculator" name="calculator">
                            <option value="MIN"><?php echo app('translator')->get('servicetypes.MIN'); ?></option>
                            <option value="HOUR"><?php echo app('translator')->get('servicetypes.HOUR'); ?></option>
                            <option value="DISTANCE"><?php echo app('translator')->get('servicetypes.DISTANCE'); ?></option>
                            <option value="DISTANCEMIN"><?php echo app('translator')->get('servicetypes.DISTANCEMIN'); ?></option>
                            <option value="DISTANCEHOUR"><?php echo app('translator')->get('servicetypes.DISTANCEHOUR'); ?></option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="description" class="col-xs-12 col-form-label"><?php echo app('translator')->get('admin.service.Description'); ?></label>
                    <div class="col-xs-10">
                        <textarea class="form-control" type="number" value="<?php echo e(old('description')); ?>" name="description" required id="description" placeholder="Description" rows="4"></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-xs-10">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="<?php echo e(route('admin.service.index')); ?>" class="btn btn-danger btn-block"><?php echo app('translator')->get('admin.cancel'); ?></a>
                            </div>
                            <div class="col-xs-12 col-sm-6 offset-md-6 col-md-3">
                                <button type="submit" class="btn btn-primary btn-block"><?php echo app('translator')->get('admin.service.Add_Service_Type'
                                ); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>