@extends('admin.layout.base')

@section('title', 'Help ')

@section('content')

    <div class="content-area py-1">
        <div class="container-fluid">
            <div class="box box-block bg-white">
                <p>We&#39;d like to thank you for deciding to use our script. We enjoyed creating it and hope you enjoy using it to achieve your goals :)&nbsp;If you want something changed to suit&nbsp;your venture&#39;s needs better, drop us a line: contact@aapbd.com</p>
            </div>
        </div>
    </div>

@endsection
